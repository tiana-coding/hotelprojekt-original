Zugangsdaten zur Datenbank:

username = "root";
password = "Bingki!2020$!";
dbname = "hotelprojekt";

Genaue Projektbeschreibung in README.md, hier nur laut Angabe die zur Inbetriebnahme notwendigen Informationen.